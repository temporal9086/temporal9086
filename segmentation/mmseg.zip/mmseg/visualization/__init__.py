# Copyright (c) OpenMMLab. All rights reserved.
from .local_visualizer import SegLocalVisualizer

__all__ = ['SegLocalVisualizer']
