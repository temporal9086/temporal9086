# Copyright (c) OpenMMLab. All rights reserved.
from .clip_text_encoder import CLIPTextEncoder

__all__ = ['CLIPTextEncoder']
